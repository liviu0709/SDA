
# **Laborator Liste simplu înlănțuite**

Laboratorul pune la dispoziție 3 fișiere
<ul>
  <li>main.c</li>
  <li>functiiLista.c</li>
  <li>lista.h</li>
</ul>

În fișierul *main.c* vom apela funcții definite în *functiiLista.c*.<br>
În fișierul *functiiLista.c* vom defini funcții pentru prelucrarea **Listelor simplu înlănțuite**.<br>
Fișierul *lista.h* reprezintă un **fișier header**.
